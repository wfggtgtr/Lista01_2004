﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._2004.R._5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n1;
            double n2;
            double n3;
            double n4;
            double resultado;

            Console.Write(" Digite o valor um:");
            n1 = double.Parse(Console.ReadLine());

            Console.Write(" Digite o valor dois:");
            n2 = double.Parse(Console.ReadLine());

            Console.Write(" Digite o valor três:");
            n3 = double.Parse(Console.ReadLine());

            Console.Write(" Digite o valor quatro:");
            n4 = double.Parse(Console.ReadLine());

            resultado = (n1 + n2 + n3 + n4) / 4;

            Console.WriteLine(" A média aritmética dos quatro valores digitados pelo usuario é {0}", resultado);
        }
    }
}
