﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1._2004
{
    internal class Program
    {
        static void Main(string[] args)
        {
           double nbase;
            double altura;
            double resultado;

            Console.WriteLine("Digite o valor da base");
            nbase = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da altura");
            altura = double.Parse(Console.ReadLine());

            resultado = nbase * altura;

            Console.WriteLine("resultado: {0}", resultado);




            
        }
    }
}
