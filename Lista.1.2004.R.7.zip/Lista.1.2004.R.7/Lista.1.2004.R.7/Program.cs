﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._2004.R._7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;

            Console.WriteLine(" Exercício 7 da Lista 1 ");
            Console.WriteLine("");

            Console.Write(" Digite um valor em Milha Marítima: ");
            valor = double.Parse(Console.ReadLine());

            resultado = valor * 1.852;

            Console.WriteLine(" Resultado em Quilômetro: {0} ", resultado);
        }
    }
}
