﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._2004.R._8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;

            Console.WriteLine(" Exercício 8 da Lista 1");
            Console.WriteLine("");

            Console.Write(" Digite um valor da temperatura em °C ");
            valor = double.Parse(Console.ReadLine());

            resultado = valor * 9 / 5 + 32;

            Console.WriteLine(" Resultado em Fahrenheit: {0}", resultado);
        }
    }
}
