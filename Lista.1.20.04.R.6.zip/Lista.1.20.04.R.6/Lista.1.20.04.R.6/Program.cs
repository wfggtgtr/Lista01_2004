﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._20._04.R._6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;
            double resultado;

            Console.WriteLine(" Exercício 6 da Lista 1");
            Console.WriteLine("");

            Console.WriteLine(" Digite o valor 1: ");
            valor1 = double.Parse(Console.ReadLine());

            Console.WriteLine(" Digite o valor 2: ");
            valor2 = double.Parse(Console.ReadLine());

            resultado = Math.Sqrt( valor1 * valor2 );

            Console.WriteLine(" Resultado da média geométrica é: {0}", resultado);
        }
    }
}
