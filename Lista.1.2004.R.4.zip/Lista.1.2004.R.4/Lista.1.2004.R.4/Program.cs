﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._2004.R._4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n1;
            double n2;
            double n3;

            Console.Write(" Digite a base do triangulo:");
            n1 = double.Parse(Console.ReadLine());

            Console.Write(" Digite a altura do triangulo:");
            n2 = double.Parse(Console.ReadLine());

            n3 = n2 * n1;
            n3 = n3 / 2;

            Console.WriteLine(" A area do triangulo é {0}", n3);
        }
    }
}
