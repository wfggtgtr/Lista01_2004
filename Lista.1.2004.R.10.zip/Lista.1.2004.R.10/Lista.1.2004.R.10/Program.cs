﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._2004.R._10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double ndolar;
            double ncotação;
            double resultado;

            Console.WriteLine(" Exercício 10 da lista 1 ");
            Console.WriteLine("");

            Console.WriteLine(" Digite um valor em Dólares: US$ ");
            ndolar = double.Parse(Console.ReadLine());

            Console.WriteLine(" Digite o valor da Cotação do Dólar: R$ ");
            ncotação = double.Parse(Console.ReadLine());

            resultado = ncotação * ndolar;

            Console.WriteLine(" Resultado em Reais: {0}", resultado. ToString());
        }
    }
}
