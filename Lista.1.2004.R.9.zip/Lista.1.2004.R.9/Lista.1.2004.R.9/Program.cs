﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._2004.R._9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;

            Console.WriteLine(" Lista 1, Exercício 9 ");
            Console.WriteLine("");

            Console.WriteLine(" Digite o valor do diâmetro do circulo: ");
            valor = double.Parse(Console.ReadLine());

            resultado = Math.PI * Math.Pow((valor / 2), 2);

            Console.WriteLine(" Valor da Área é : {0}", resultado);
        }
    }
}
