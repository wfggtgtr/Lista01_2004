﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._2004.R._11
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double xbase;
            double yexpoente;
            double zresultado;

            Console.WriteLine(" Exercício 11 da Lista 1");
            Console.WriteLine();

            Console.Write(" Digite o valor da Base: ");
            xbase = double.Parse(Console.ReadLine());

            Console.Write(" Digite o valor do Expoente: ");
            yexpoente = double.Parse(Console.ReadLine());

            zresultado = Math.Pow(xbase, yexpoente);

            Console.WriteLine(" Resultado do cálculo é : {0}", zresultado);
        }
    }
}
