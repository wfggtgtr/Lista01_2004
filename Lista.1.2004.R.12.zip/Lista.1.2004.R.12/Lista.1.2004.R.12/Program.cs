﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._2004.R._12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nproduto1;
            double nproduto2;
            double nproduto3;
            double nproduto4;
            double nproduto5;
            double resultado;
            double npagamento;
            double nvalortroco;

            Console.WriteLine(" Exercício 12 da Lista 1 ");
            Console.WriteLine("");

            Console.Write(" Digite o valor do produto 1: R$");
            nproduto1 = double.Parse(Console.ReadLine());

            Console.Write(" Digite o valor do produto 2: R$");
            nproduto2 = double.Parse(Console.ReadLine());

            Console.Write(" Digite o valor do produto 3: R$");
            nproduto3 = double.Parse(Console.ReadLine());

            Console.Write(" Digite o valor do produto 4: R$");
            nproduto4 = double.Parse(Console.ReadLine());

            Console.Write(" Digite o valor do produto 5: R$");
            nproduto5 = double.Parse(Console.ReadLine());

            resultado = nproduto1 + nproduto2 + nproduto3 + nproduto4 + nproduto5;

            Console.WriteLine(" Valor dos produtos em Reais: {0}", resultado);

            Console.Write("Digite o valor do pagamento: R$");
            npagamento = double.Parse(Console.ReadLine());

            nvalortroco = npagamento - resultado;

            Console.WriteLine(" Valor do troco em Reais: {0}", nvalortroco. ToString("C"));
        }
    }
}
