﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista._1._2004.R._3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nlado;
            double ndiagonal;
            double narea;

            Console.WriteLine(" Exercício 3 da Lista 1 ");
            Console.WriteLine("");

            Console.WriteLine(" Digite o valor da diagonal: ");
            ndiagonal = double.Parse(Console.ReadLine());

            nlado = ndiagonal / Math.Sqrt(2);

            Console.WriteLine(" O comprimento do lado é: {0}", nlado);

            narea = nlado * nlado;

            Console.WriteLine(" O valor da área do quadrado é: {0}", narea);            
        }
    }
}
